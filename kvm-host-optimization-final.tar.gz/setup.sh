#!/bin/bash

# KVM Host Optimization Setup Script
# This script prepares the Debian Bookworm host for Ansible pull workflow

set -e

REPO_URL="https://github.com/your-repo/kvm-host-optimization.git"
INSTALL_DIR="/opt/kvm-host-optimization"
LOG_FILE="/var/log/kvm-host-setup.log"

echo "=== KVM Host Optimization Setup ===" | tee -a $LOG_FILE
echo "Started at: $(date)" | tee -a $LOG_FILE

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root" | tee -a $LOG_FILE
   exit 1
fi

# Update system
echo "Updating system packages..." | tee -a $LOG_FILE
apt-get update && apt-get upgrade -y >> $LOG_FILE 2>&1

# Install required packages
echo "Installing required packages..." | tee -a $LOG_FILE
apt-get install -y \
    ansible \
    git \
    python3-pip \
    python3-venv \
    curl \
    wget \
    gnupg \
    software-properties-common >> $LOG_FILE 2>&1

# Create installation directory
echo "Creating installation directory..." | tee -a $LOG_FILE
mkdir -p $INSTALL_DIR
cd $INSTALL_DIR

# Clone repository (or copy local files for testing)
echo "Setting up Ansible playbook..." | tee -a $LOG_FILE
if [[ -d ".git" ]]; then
    git pull >> $LOG_FILE 2>&1
else
    # For testing, copy local files
    if [[ -f "/tmp/kvm-host-optimization.tar.gz" ]]; then
        tar -xzf /tmp/kvm-host-optimization.tar.gz -C . >> $LOG_FILE 2>&1
    else
        echo "Repository URL not configured. Please set REPO_URL variable." | tee -a $LOG_FILE
        echo "For testing, place files in $INSTALL_DIR" | tee -a $LOG_FILE
    fi
fi

# Set proper permissions
chown -R root:root $INSTALL_DIR
chmod -R 755 $INSTALL_DIR

# Copy systemd service and timer
echo "Setting up systemd service..." | tee -a $LOG_FILE
cp ansible-pull.service /etc/systemd/system/
cp ansible-pull.timer /etc/systemd/system/

# Reload systemd
systemctl daemon-reload

# Enable and start the timer
echo "Enabling Ansible pull timer..." | tee -a $LOG_FILE
systemctl enable ansible-pull.timer
systemctl start ansible-pull.timer

# Run initial optimization
echo "Running initial optimization..." | tee -a $LOG_FILE
ansible-playbook -i inventory/hosts.yml site.yml >> $LOG_FILE 2>&1

# Create log rotation for our logs
cat > /etc/logrotate.d/kvm-host-optimization << 'EOF'
/var/log/kvm-host-setup.log {
    daily
    rotate 7
    compress
    delaycompress
    missingok
    notifempty
    create 0644 root root
}

/var/log/kvm-optimization.log {
    daily
    rotate 30
    compress
    delaycompress
    missingok
    notifempty
    create 0644 root root
}
EOF

# Display status
echo "=== Setup Complete ===" | tee -a $LOG_FILE
echo "Installation directory: $INSTALL_DIR" | tee -a $LOG_FILE
echo "Service status:" | tee -a $LOG_FILE
systemctl status ansible-pull.timer --no-pager | tee -a $LOG_FILE

echo "Timer schedule:" | tee -a $LOG_FILE
systemctl list-timers ansible-pull.timer --no-pager | tee -a $LOG_FILE

echo "Setup completed at: $(date)" | tee -a $LOG_FILE

# Show next optimization run
echo ""
echo "Next optimization run:"
systemctl list-timers ansible-pull.timer --no-pager | grep ansible-pull

echo ""
echo "To manually run optimization:"
echo "  systemctl start ansible-pull.service"
echo ""
echo "To check logs:"
echo "  journalctl -u ansible-pull.service -f"
echo "  tail -f /var/log/kvm-optimization.log"
echo ""
echo "To stop automatic optimization:"
echo "  systemctl stop ansible-pull.timer"
echo "  systemctl disable ansible-pull.timer"